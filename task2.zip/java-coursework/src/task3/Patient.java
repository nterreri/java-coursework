package task3;

import java.util.ArrayList;

public class Patient {
	//private:
	//fields:
	String pid;
	String l_name;
	String f_name;
	String DOB;
	String address;
	String emergency_phone;
	String condition;
	ArrayList<???> appointments;
	??? billing;
	ArrayList<String> comments;
}
